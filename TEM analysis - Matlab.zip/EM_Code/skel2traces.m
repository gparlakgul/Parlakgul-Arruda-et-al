function traces = skel2traces(skel)
% traces = skel2traces(skel)
% traces binary skeleton image (obtained with bwmorph(_,'skel',Inf))
%
% input:
%     binary skeleton image, obtained with bwmorph(_,'skel',Inf)
% output:
%     cell array with traces; each trace is a Nx2 matrix, where N is the
%     number of points in the trace, the first column corresponds to row
%     coordinates, and the second to column coordinates
% use 'checkTracing' to check correctness of tracing
% use 'traceLength' to measure length of traces
%
% example:
%     I = imread('rice.png');
%     I = imtophat(I,strel('disk',12));
%     bw = imbinarize(I);
%     skel = bwmorph(bw,'skel',Inf);
%     traces = skel2traces(skel);
%     t = cat(1,traces{:});
%     imshow(skel), hold on, plot(t(:,2),t(:,1),'.'), hold off
%     out = checkTracing(skel,traces);
%     if out
%         disp('found all traces')
%     else
%         disp('did not find all traces')
%     end
%     disp('total length')
%     disp(traceLength(traces))
%
% WARNING:
%     function doesn't trace loops (closed curves), because
%     bwmorph(skel,'endpoints') doesn't return endpoints in that case
%
% Marcelo Cicconet, Dec 13 2017

ep = bwmorph(skel,'endpoints');

BW = zeros(size(skel,1)+2,size(skel,2)+2);
BW(2:size(skel,1)+1,2:size(skel,2)+1) = skel;

EP = zeros(size(ep,1)+2,size(ep,2)+2);
EP(2:size(ep,1)+1,2:size(ep,2)+1) = ep;

% BWT = zeros(size(BW)); % traces
% BW0 = BW;
% EP0 = EP;

count = 0;

[r0,c0] = find(EP,1);
while ~isempty(r0)
    P = BW(r0-1:r0+1,c0-1:c0+1);
    P(2,2) = 0;
    [rr,cc] = find(P);
%     BWT(r0,c0) = 1;
    BW(r0,c0) = 0;
    EP(r0,c0) = 0;
    trace = [];
    trace = [trace; [r0-1 c0-1]];
%     imshow([BW BWT])
    while ~isempty(rr)
        if numel(rr) > 1
            for i = 2:numel(rr)
                EP(r0-2+rr(i),c0-2+cc(i)) = 1;
            end
        end
        r0 = r0-2+rr(1);
        c0 = c0-2+cc(1);
        P = BW(r0-1:r0+1,c0-1:c0+1);
        P(2,2) = 0;
        [rr,cc] = find(P);
%         BWT(r0,c0) = 1;
        BW(r0,c0) = 0;
        EP(r0,c0) = 0;
        trace = [trace; [r0-1 c0-1]];
%         imshow([BW BWT])
    end
    count = count+1;
    traces{count} = trace;
%     imshow([BW BWT])
%     pause
    [r0,c0] = find(EP,1);
end

% bwt = BWT(2:size(skel,1)+1,2:size(skel,2)+1);

end