function m = max2(I)

m = max(max(I));

end