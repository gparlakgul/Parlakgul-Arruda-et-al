function [T,J,K,nTraces,fractionHasNN,lengthTotal,lengthFractionHasNN] = traceDensity(I,varargin)
% [T,J,K,fractionHasNN,lengthTotal,lengthFractionHasNN] = traceDensity(I,varargin)
% analyzes the density of filaments in image
%
% ----- inputs -----
% I
%     single-channel image containing traces
%     every pixel > 0 is considered as belonging to a trace
% 'nnSearchRange', optional, default [5 20]
%     range of search for nearby neighbor at the direction perpendicular to
%     the tangent to the curve
% 'thrNN', optional, default 0.5
%     threshold for a trace to be considered as having a nearby neighbor;
%     if the fraction of the points in the trace that have a nearby neighbor
%     at distance in nnSearchRange is above this threshold,
%     the entire trace is considered as having a nearby neighbor
% 'labelTraces', optional, default false
%     flag determining if the output image should have labels corresponding
%     to the trace ID; this is useful when debugging, by comparing the table
%     and image outputs; however it takes a long time to generate such
%     image, so it is recommended to set this to false during deployment
%
% ----- outputs -----
% T
%     table with trace properties: 'ID','r0','c0','length','fraction_nn','has_nn'
% J
%     image with traces colored red (if they don't pass the nn test) or
%     blue (if the pass the nn test), optionally with trace ID's if
%     labelTraces = true
% K
%     image with only the traces that pass test (in blue)
% nTraces
%     total number of traces
% fractionHasNN
%     fraction of traces that pass the nn test
% lengthTotal
%     total length of traces
% lengthFractionHasNN
%     fraction of total length corresponding to traces that pass the nn test
%
% -----
% 
% Marcelo Cicconet, Dec 20 2017


p = inputParser; 
p.addParameter('nnSearchRange',[5 20]);
p.addParameter('thrNN',0.5);
p.addParameter('labelTraces',false);
p.parse(varargin{:});
p = p.Results;

nnSearchRange = p.nnSearchRange;
thrNN = p.thrNN;
labelTraces = p.labelTraces;

padI = zeros(size(I,1)+2*nnSearchRange(2),size(I,2)+2*nnSearchRange(2));
padI(nnSearchRange(2)+1:nnSearchRange(2)+size(I,1),nnSearchRange(2)+1:nnSearchRange(2)+size(I,2)) = I;
I = padI;

skel = bwmorph(I > 0,'skel',Inf);
disp('tracing')
traces = skel2traces(skel);
if checkTracing(skel,traces)
    disp('  traces reconstruct skeleton')
else
    disp('  traces do not reconstruct skeleton: possible closed loops')
end

nTraces = 0;
for i = 1:length(traces)
    if size(traces{i},1) > 1
        nTraces = nTraces+1;
    end
end
statsDensity = zeros(nTraces,1);
lengths = zeros(nTraces,1);
hasNN = zeros(nTraces,1);
r0s = zeros(nTraces,1);
c0s = zeros(nTraces,1);

J = ones(size(I,1),size(I,2),3);
K = ones(size(I,1),size(I,2),3);
traceCount = 0;
if labelTraces
    strings = cell(nTraces,1);
end
disp('computing trace density, properties')
for i = 1:length(traces)
    t = traces{i};
    if size(t,1) > 1
        traceCount = traceCount+1;
        u = t;
        for j = 1:3
            u  = [smooth(u(:,1)) smooth(u(:,2))];
        end
        nhits = 0;
        for j = 1:size(u,1)-1
            v = u(j+1,:)-u(j,:);
            v = v/norm(v);
            v = [-v(2) v(1)];
            for k = nnSearchRange(1):nnSearchRange(2)
                rc = round(u(j,:)+k*v);
                if skel(rc(1),rc(2)) == 1
                    nhits = nhits+1;
                    break;
                end
                rc = round(u(j,:)-k*v);
                if skel(rc(1),rc(2)) == 1
                    nhits = nhits+1;
                    break;
                end
            end
        end

        test = nhits/size(u,1) > thrNN;
        d = diff(u);
        l = sum(sqrt(d(:,1).^2+d(:,2).^2));
        lengths(traceCount) = l;
        statsDensity(traceCount) = nhits/size(u,1);
        hasNN(traceCount) = test;
        if labelTraces
            strings{traceCount} = sprintf('%d',traceCount);
        end
        
        u = round(u);
        r0s(traceCount) = u(1,1);
        c0s(traceCount) = u(1,2);
        for j = 1:size(t,1)
            J(t(j,1),t(j,2),:) = 0;
            J(u(j,1),u(j,2),:) = 0;
            J(u(j,1),u(j,2),test*3+(1-test)) = 1;
        end
        if test
            for j = 1:size(t,1)
                K(u(j,1),u(j,2),:) = 0;
                K(u(j,1),u(j,2),3) = 1;
            end
        end
    end
end

if labelTraces
    disp('labeling traces');
    J = insertText(J,[c0s r0s],strings,'FontSize',10,'TextColor','black','BoxOpacity',0);
end

fractionHasNN = sum(hasNN)/nTraces;
lengthTotal = sum(lengths);
lengthFractionHasNN = sum(hasNN.*lengths);

A = [(1:nTraces)' r0s c0s lengths statsDensity hasNN];
T = array2table(A,'VariableNames',{'ID','r0','c0','length','fraction_nn','has_nn'});

end