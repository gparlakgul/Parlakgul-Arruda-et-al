function [output,T] = checkTracing(skel,traces)
% [output,T] = checkTracing(skel,traces)
% checks if the output of skel2traces is correct
% inputs:
%     skel: the input of skel2traces
%     traces: the output of skel2traces
% outputs:
%     output: 0 (skel2traces didn't find all traces)
%             1 (skel2traces did find all traces)
%     T: binary image reconstructed from traces
%
% see 'skel2traces' for an example
%
% Marcelo Cicconet, Dec 13 2017

T = false(size(skel));
for i = 1:length(traces)
    trace = traces{i};
    for j = 1:size(trace,1)
        T(trace(j,1),trace(j,2)) = true;
    end
end
if max2(abs(T-skel)) > 0
    output = 0;
else
    output = 1;
end

end