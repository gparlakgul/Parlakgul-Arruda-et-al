fpath = '/Users/Gunes/Desktop/Matlab_input/';
% path to folder of images to analyze
% only images to analyze should be in such folder;
% expected format is '.tif'

nnSearchRange = [10 40];
% range of search for nearby neighbor at the direction perpendicular to
% the tangent to the curve

thrNN = 0.5;
% threshold for a trace to be considered as having a nearby neighbor;
% if the fraction of the points in the trace that have a nearby neighbor
% at distance in nnSearchRange is above this threshold,
% the entire trace is considered as having a nearby neighbor

labelTraces = false;
% flag determining if the output image should have labels corresponding
% to the trace ID; this is useful when debugging, by comparing the table
% and image outputs; however it takes a long time to generate such
% image, so it is recommended to set this to false during deployment

% -----
% no parameters to set beyond this point
% -----

fplist = listfilesexcluding(fpath,'.tif','_Output');

nImages = length(fplist);
summaryCell = cell(nImages,4);
for i = 1:nImages
    fprintf('\nanalyzing image %d of %d\n',i,nImages);
    I = imread(fplist{i});
    I = I(:,:,1);
    [T,J,K,nTraces,fractionHasNN,lengthTotal,lengthFractionHasNN] = traceDensity(I,'nnSearchRange',nnSearchRange,'thrNN',thrNN,'labelTraces',labelTraces);
    [~,name] = fileparts(fplist{i});
    imwrite(J,[fpath filesep name '_OutputJ.tif']);
    imwrite(K,[fpath filesep name '_OutputK.tif']);
    writetable(T,[fpath filesep name '_Output.xls']);
    dt = [nTraces,fractionHasNN,lengthTotal,lengthFractionHasNN];
    summaryCell{i,1} = name;
    for j = 1:4
        summaryCell{i,1+j} = dt(j);
    end
end

variableNames = {'image','n_traces','fraction_has_nn','length_total','length_fraction_has_nn'};
T = cell2table(summaryCell,'VariableNames',variableNames);
writetable(T,[fpath filesep '_Summary_Output.xls']);