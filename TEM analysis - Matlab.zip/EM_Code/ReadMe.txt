The main file is batchTraceDensity.m
See that file for more details.