# parameters to set

planesFolderPath = 'G:\\Data\\Cropped VOIs\\OBJ\\Tiff Stacks of VOIs\\6464\\6464 ER'
outPlanesFolderPathC1 = 'G:\\Data\\Cropped VOIs\\OBJ\\Tiff Stacks of VOIs\\6464\\6464 VOI1 ER Tubules'
outPlanesFolderPathC2 = 'G:\\Data\\Cropped VOIs\\OBJ\\Tiff Stacks of VOIs\\6464\\6464 VOI1 ER Sheets'

# -------------------------


import numpy as np
import tensorflow as tf
import os, shutil, sys

from tensorflow.keras.layers import Dense, Conv2D, Conv2DTranspose, UpSampling2D, MaxPooling2D, Flatten, concatenate, Cropping2D, Activation
from tensorflow.keras import Input, Model

os.environ['CUDA_VISIBLE_DEVICES']='0'

import sys
# sys.path.insert(0, '/home/mc457/Documents/Python/ImageScience')
from toolbox.imtools import *
from toolbox.ftools import *
from toolbox.ttools import *
from toolbox.PartitionOfImageVC import PI2D


# imSize = 60 # output size 20
imSize = 524#108,220,524,1004 # output size 20,132
nClasses = 3
nChannels = 3
batchSize = 16#8
bn = True

imPath = '/scratch/Gunes/TrainingSet2_ClassBalanced_108'
imPathTest = '/scratch/Gunes/TrainingSet2_ClassBalanced'
nImages = 0#len(listfiles(imPath,'_Img.tif'))
nImagesTest = 0#len(listfiles(imPathTest,'_Img.tif'))

# dsm = 0.25
# dss = 0.43

# maxBrig = 1
# maxCont = 0.5

def getBatch(n):
    x_batch = np.zeros((n,imSize,imSize,nChannels))
    y_batch = np.zeros((n,imSize,imSize,nClasses))

    perm = np.random.permutation(nImages)

    for i in range(n):
        I = im2double(tifread(pathjoin(imPath,'I%05d_Img.tif' % perm[i])))

        # I = (I-dsm)/dss
        # fBrig = maxBrig*np.float_power(-1,np.random.rand() < 0.5)*np.random.rand()
        # fCont = 1+maxCont*np.float_power(-1,np.random.rand() < 0.5)*np.random.rand()
        # I = I*fCont+fBrig

        A = tifread(pathjoin(imPath,'I%05d_Ant.tif' % perm[i]))
        for j in range(nChannels):
            x_batch[i,:,:,j] = I[j,:,:]
        for j in range(nClasses):
            y_batch[i,:,:,j] = A == (j+1)

    return x_batch, y_batch



# https://lmb.informatik.uni-freiburg.de/Publications/2019/FMBCAMBBR19/paper-U-Net.pdf

x = Input((imSize,imSize,nChannels))
t = tf.placeholder(tf.bool)
ccidx = []

hidden = [tf.to_float(x)]
print('layer',len(hidden)-1,':',hidden[-1].shape,'input')

# nFeatMapsList = [16,32,64] # length should be 3 for input 60 to have output 20
nFeatMapsList = [16,32,64,128] # length should be 4 for input 108 to have output 20

# down

for i in range(len(nFeatMapsList)-1):
    print('...')
    nFeatMaps = nFeatMapsList[i]
    hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
    if bn:
        hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
    hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
    if bn:
        hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
    hidden.append(Activation('relu')(hidden[-1]))
    ccidx.append(len(hidden)-1)
    print('layer',len(hidden)-1,':',hidden[-1].shape,'after conv conv bn')
    # hidden.append(MaxPooling2D()(hidden[-1]))
    hidden.append(Conv2D(nFeatMaps,(2),padding='valid',activation=None,strides=2)(hidden[-1]))
    print('layer',len(hidden)-1,':',hidden[-1].shape,'after downsampling')

# bottom

i = len(nFeatMapsList)-1
print('...')
nFeatMaps = nFeatMapsList[i]
hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
if bn:
    hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
if bn:
    hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
hidden.append(Activation('relu')(hidden[-1]))
# hidden.append(tf.nn.batch_normalization(hidden[-1], bnm[len(bna)], bns[len(bna)], 0.0, 1.0, 0.000001))
# hidden.append((hidden[-1]-bnm[len(bna)])/bns[len(bna)])
# bna.append(hidden[-1])
# print('len bna',len(bna))
print('layer',len(hidden)-1,':',hidden[-1].shape,'after conv conv bn')
print('...')

# up
for i in range(len(nFeatMapsList)-1):
    nFeatMaps = nFeatMapsList[-i-2]
    # hidden.append(Conv2DTranspose(nFeatMaps,(3),strides=(2),padding='same',activation='relu')(hidden[-1]))
    hidden.append(UpSampling2D(size=2)(hidden[-1]))
    print('layer',len(hidden)-1,':',hidden[-1].shape,'after upsampling')
    toCrop = int((hidden[ccidx[-1-i]].shape[1]-hidden[-1].shape[1])//2)
    hidden.append(concatenate([hidden[-1], Cropping2D(toCrop)(hidden[ccidx[-1-i]])]))
    print('layer',len(hidden)-1,':',hidden[-1].shape,'after concat with cropped layer %d' % ccidx[-1-i])
    hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
    if bn:
        hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
    hidden.append(Conv2D(nFeatMaps,(3),padding='valid',activation=None)(hidden[-1]))
    if bn:
        hidden.append(tf.layers.batch_normalization(hidden[-1], training=t))
    hidden.append(Activation('relu')(hidden[-1]))
    # hidden.append(tf.nn.batch_normalization(hidden[-1], bnm[len(bna)], bns[len(bna)], 0.0, 1.0, 0.000001))
    # hidden.append((hidden[-1]-bnm[len(bna)])/bns[len(bna)])
    # bna.append(hidden[-1])
    # print('len bna',len(bna))
    print('layer',len(hidden)-1,':',hidden[-1].shape,'after conv conv bn')
    print('...')

# last

hidden.append(Conv2D(nClasses,(1),padding='same',activation='softmax')(hidden[-1]))
print('layer',len(hidden)-1,':',hidden[-1].shape,'output')

# sys.exit(0)

sm = hidden[-1]
y0 = Input((imSize,imSize,nClasses))
toCrop = int((y0.shape[1]-sm.shape[1])//2)
y = Cropping2D(toCrop)(y0)
cropSize = y.shape[1]



# https://www.jeremyjordan.me/semantic-segmentation/
# https://arxiv.org/pdf/1606.04797.pdf

iClass = 0
yC0 = tf.slice(y,[0,0,0,iClass],[-1,-1,-1,1])
smC0 = tf.slice(sm,[0,0,0,iClass],[-1,-1,-1,1])
itsc = tf.multiply(yC0,smC0)
numEl_itsc = tf.reduce_sum(itsc,axis=[1,2,3])
numEl_yC0 = tf.reduce_sum(tf.square(yC0),axis=[1,2,3])
numEl_smC0 = tf.reduce_sum(tf.square(smC0),axis=[1,2,3])
diceCoeff = 2*tf.divide(numEl_itsc,numEl_yC0+numEl_smC0)
diceLoss0 = tf.reduce_mean(1-diceCoeff)

iClass = 1
yC0 = tf.slice(y,[0,0,0,iClass],[-1,-1,-1,1])
smC0 = tf.slice(sm,[0,0,0,iClass],[-1,-1,-1,1])
itsc = tf.multiply(yC0,smC0)
numEl_itsc = tf.reduce_sum(itsc,axis=[1,2,3])
numEl_yC0 = tf.reduce_sum(tf.square(yC0),axis=[1,2,3])
numEl_smC0 = tf.reduce_sum(tf.square(smC0),axis=[1,2,3])
diceCoeff = 2*tf.divide(numEl_itsc,numEl_yC0+numEl_smC0)
diceLoss1 = tf.reduce_mean(1-diceCoeff)


diceLoss = (diceLoss0+diceLoss1)/2


l = []
# nl = []
for iClass in range(nClasses):
    labels0 = tf.reshape(tf.to_int32(tf.slice(y,[0,0,0,iClass],[-1,-1,-1,1])),[batchSize,cropSize,cropSize])
    predict0 = tf.reshape(tf.to_int32(tf.equal(tf.argmax(sm,3),iClass)),[batchSize,cropSize,cropSize])
    correct = tf.multiply(labels0,predict0)
    nCorrect0 = tf.reduce_sum(correct)
    nLabels0 = tf.reduce_sum(labels0)
    l.append(tf.to_float(nCorrect0)/tf.to_float(nLabels0))
    # nl.append(nLabels0)
acc = tf.add_n(l)/nClasses

loss = -tf.reduce_sum(tf.multiply(y,tf.log(sm)))
# loss = diceLoss
updateOps = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
optimizer = tf.train.AdamOptimizer(0.00001)
# optimizer = tf.train.MomentumOptimizer(0.0001,0.99)
if bn:
    with tf.control_dependencies(updateOps):
        optOp = optimizer.minimize(loss)
    # optOp = optimizer.minimize(loss)
    # optOp = tf.group([optOp, updateOps])
    # https://www.tensorflow.org/versions/r1.15/api_docs/python/tf/layers/batch_normalization
    # https://towardsdatascience.com/batch-normalization-theory-and-how-to-use-it-with-tensorflow-1892ca0173ad
else:
    optOp = optimizer.minimize(loss)


# tf.summary.scalar('loss', loss)
# tf.summary.scalar('acc', acc)
# mergedsmr = tf.summary.merge_all()
# logDir = '/scratch/Gunes/Logs/log'
# if os.path.exists(logDir):
#     shutil.rmtree(logDir)
# writer = tf.summary.FileWriter(logDir)


sess = tf.Session()
saver = tf.train.Saver()

restoreVariables = True
if restoreVariables:
    saver.restore(sess, 'G:\\ER_Mask_Segmentation\\Models\\model.ckpt')
else:
    sess.run(tf.global_variables_initializer())

def testOnImage(index,bnFlag):
    V = im2double(tifread(pathjoin(imPathTest,'I%05d_Img.tif' % index)))

    # V = (V-dsm)/dss

    # margin = 20
    margin = 44
    PI2D.setup(V,imSize,margin)
    PI2D.createOutput(3)
    nImages = PI2D.NumPatches

    x_batch = np.zeros((batchSize,imSize,imSize,nChannels))

    print('test on image',index,'bn',bnFlag)
    for i in range(nImages):
        P = PI2D.getPatch(i)

        j = np.mod(i,batchSize)
        for k in range(nChannels):
            x_batch[j,:,:,k] = P[k,:,:]

        if j == batchSize-1 or i == nImages-1:
            if bn:
                output = sess.run(sm,feed_dict={x: x_batch, t: bnFlag})
            else:
                output = sess.run(sm,feed_dict={x: x_batch})
            for k in range(j+1):
                PI2D.patchOutput(i-j+k,np.moveaxis(output[k,:,:,0:3],[2,0,1],[0,1,2]))

    PM = PI2D.Output
    PM0 = PM[0,margin:-margin,margin:-margin]
    PM1 = PM[1,margin:-margin,margin:-margin]

    V0 = normalize(V[1,margin:-margin,margin:-margin])
    C = np.concatenate((V0,PM0),axis=1)
    C = np.concatenate((C,PM1),axis=1)

    return np.uint8(255*C)



train = False
if train:
    ma = 0.5
    for i in range(10*nImages):
        x_batch, y_batch = getBatch(batchSize)

        if bn:
            smr,vLoss,a,_ = sess.run([mergedsmr,loss,acc,optOp],feed_dict={x: x_batch, y0: y_batch, t: True})
        else:
            smr,vLoss,a,_ = sess.run([mergedsmr,loss,acc,optOp],feed_dict={x: x_batch, y0: y_batch})
        writer.add_summary(smr, i)
        print('step', '%05d' % i, 'epoch', '%05d' % int(i/nImages), 'acc', '%.02f' % a, 'loss', '%.02f' % vLoss)
        ma = 0.5*ma+0.5*a
        if ma > 0.9999:
            saver.save(sess, '/scratch/Gunes/Models/model.ckpt')
            break

        if i % 100 == 0:
            imIndex = np.random.randint(nImagesTest)
            outBN0 = testOnImage(imIndex,False)

            tifwrite(outBN0,'/scratch/Gunes/Scratch.tif')


            if a > 0.7:
                saver.save(sess, '/scratch/Gunes/Models/model.ckpt')
                print('model saved')

# writer.close()

from PIL import Image
def blendRGBImages(image1,image2):
    image1 = Image.fromarray(image1)
    image2 = Image.fromarray(image2)

    image1 = image1.convert('RGBA')
    image2 = image2.convert('RGBA')

    blended = Image.blend(image1, image2, alpha=0.5)

    return np.array(blended)

deploy = True


planesPathList = listfiles(planesFolderPath,'.tif')
outPlanesFolderPaths = [outPlanesFolderPathC1,outPlanesFolderPathC2]

if deploy:
    for imIndex in range(len(planesPathList)):
    #for imIndex in range(5621, 5638+1):

        # filePath = planesPathList[imIndex]
        # [_,name,_] = fileparts(filePath)

        idx0 = np.maximum(imIndex-1,0)
        #idx0 = np.maximum(imIndex-1,5621)
        idx1 = imIndex
        idx2 = np.minimum(imIndex+1,len(planesPathList)-1)
        #idx2 = np.minimum(imIndex+1,5638)

        # print(idx0,idx1,idx2,len(planesPathList))


        name0 = '6464 VOI-2 ER_T001_Z%03d_C02' % (idx0+1)
        name1 = '6464 VOI-2 ER_T001_Z%03d_C02' % (idx1+1)
        name2 = '6464 VOI-2 ER_T001_Z%03d_C02' % (idx2+1)
        name = name1


        print(name0,'|',name1,'|',name2,'...',len(planesPathList))

        # V0 = im2double(tifread(planesPathList[idx0]))
        # V1 = im2double(tifread(planesPathList[idx1]))
        # V2 = im2double(tifread(planesPathList[idx2]))

        V0 = im2double(tifread(pathjoin(planesFolderPath,name0+'.tif')))
        V1 = im2double(tifread(pathjoin(planesFolderPath,name1+'.tif')))
        V2 = im2double(tifread(pathjoin(planesFolderPath,name2+'.tif')))


        V = np.zeros((3,V0.shape[0],V0.shape[1]))
        V[0,:,:] = V0
        V[1,:,:] = V1
        V[2,:,:] = V2

        # p = 'G:\\ER_Mask_Segmentation\\SampleData\\I%05d_Img.tif' % imIndex
        # V = im2double(tifread(p))

        # margin = 20
        margin = 44

        t0 = tic()

        PI2D.setup(V,imSize,margin)
        PI2D.createOutput(3)
        nImages = PI2D.NumPatches

        x_batch = np.zeros((batchSize,imSize,imSize,nChannels))

        for i in range(nImages):
            # print(imIndex,i,nImages)
            P = PI2D.getPatch(i)

            j = np.mod(i,batchSize)
            for k in range(nChannels):
                x_batch[j,:,:,k] = P[k,:,:]

            if j == batchSize-1 or i == nImages-1:
                output = sess.run(sm,feed_dict={x: x_batch, t: False})
                for k in range(j+1):
                    PI2D.patchOutput(i-j+k,np.moveaxis(output[k,:,:,0:3],[2,0,1],[0,1,2]))

        toc(t0)

        PM = PI2D.Output
        # PM0 = PM[0,margin:-margin,margin:-margin]
        # PM1 = PM[1,margin:-margin,margin:-margin]
        # V0 = normalize(V[1,margin:-margin,margin:-margin])

        # PM0 = PM[0,:,:]
        # PM1 = PM[1,:,:]
        # V0 = V[1,:,:]
        # tifwrite(255*np.uint8(V0),'G:\\ER_Mask_Segmentation\\SampleData\\Predict\\I%05d_Im.tif' % imIndex)

        A = np.argmax(PM,axis=0)
        S = np.sum(PM,axis=0)
        A[S == 0] = -1
        for i in range(2):
            tifwrite(255*np.uint8(A == i),pathjoin(outPlanesFolderPaths[i],'%s.tif' % name))

        # C = np.zeros((V0.shape[0],V0.shape[1],3))
        # C[:,:,0] = V0
        # C[:,:,1] = V0
        # C[:,:,2] = V0
        # image1 = np.uint8(255*C)
        # tifwrite(image1,'/scratch/Gunes/Predict/I%05d_Im.tif' % imIndex)

        # C[:,:,0] = imgaussfilt(PM0,2)
        # C[:,:,1] = imgaussfilt(PM1,2)
        # C[:,:,2] = 0
        # image2 = np.uint8(255*C)
        # tifwrite(image2,'/scratch/Gunes/Predict/I%05d_PM.tif' % imIndex)

        # B = blendRGBImages(image1,image2)
        # tifwrite(B,'/scratch/Gunes/Predict/I%05d.tif' % imIndex)


sess.close()
