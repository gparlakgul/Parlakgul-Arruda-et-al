import time

def tic():
    return time.time()

def toc(t0):
    print('elapsed time:', time.time()-t0)

def pause(interval):
    time.sleep(interval)

# Example:
#
# t0 = tic()
# pause(0.5)
# toc(t0)